<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Penjualan_model;
use App\Models\Product_model;

class Penjualan extends BaseController
{

    public function index()
    {
        $logged = session()->get('logged_in');

        if ($logged == TRUE) {

            $data['menu'] = '';
            echo template('Penjualan/form_penjualan', $data);
        } else {

            return redirect()->to('/auth');
        }
    }
    public function save()
    {
        $model = new Penjualan_model();
        $pmodel = new Product_model();

        $baris = $this->request->getPost('baris');
        $no = '160';
        $dataHeader = array(
            // 'id_mutasi'        => $no,
            'tgl_sell'        => $this->request->getPost('tgljual'),
            'name_customer'        => $this->request->getPost('namacustomer'),
            'item_sell' => $this->request->getPost('item'),
            'total_sell' => $this->request->getPost('UangCash'),
            'disk_sell' => $this->request->getPost('disc'),
            'bayar_sell' => $this->request->getPost('TotalBayar')
        );
        $data = $model->saveSell($dataHeader);

        if ($data) {

            for ($i = 1; $i <= $baris; $i++) {
                $dataDetail = array(
                    'sell_id'        => $no,
                    'product_id'       => $this->request->getPost('idproduct' . $i),
                    'product_name'        => $this->request->getPost('nameproduct' . $i),
                    'product_price' => $this->request->getPost('harga' . $i),
                    'product_qty' => $this->request->getPost('jumlah_beli' . $i)
                );

                $id = $this->request->getPost('idproduct' . $i);
                $qty = $this->request->getPost('jumlah_beli' . $i);

                $data = $model->saveDetailSell($dataDetail);
                $data = $pmodel->kurangiStock($id, $qty);
            }
            if ($data) {
                echo '200';
            } else {
                echo '300';
            }
        } else {
            echo '300';
        }
    }
}
