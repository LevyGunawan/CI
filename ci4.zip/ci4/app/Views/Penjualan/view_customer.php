<div class="container-fluid dashboard-content ">
    <div class="row">

        <main role="main" class="col-md-9 ml-sm-auto col-lg-12 px-md-4">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <h2 class="card-header">Supplier</h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <div class="btn-group mr-2">
                                    <div class="float-right"><a href="javascript:void(0);" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#FormModal"><span class="fa fa-plus"></span> Tambah Data</a></div>
                                    <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                                </div>
                            </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered first">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama Customer</th>
                                        <th>Alamat Customer</th>
                                        <th>No Telepon</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="tblcustomer">
                                    <!--  disini nanti akan muncul tabel yang dikirim dari coding ajax pada javascript
            sehingga tbody di berikan ID agar tidak salah saat pengiriman data 
          sama seperti primarykey agar tidak salah alamat
          -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<!-- MODAL ADD di Ubah Menajadi FormModal pada id nya tujuannya agar form ini dapat digunakan untuk input dan update-->
<form>
    <div class="modal fade" id="FormModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Form Input Customer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!--  Paste disini -->
                    <input type="hidden" class="form-control" name="idcustomer" id="idcustomer" value="">
                    <div class="form-group col-md-7">
                        <label for="exampleInputEmail1">Nama Customer</label>
                        <input type="text" class="form-control" name="namacustomer" id="namacustomer" aria-describedby="emailHelp" placeholder="Enter Name Customer">
                    </div>
                    <div class="form-group col-md-7">
                        <label for="exampleInputEmail1">Alamat Supplier</label>
                        <input type="text" class="form-control" name="addresscustomer" id="addresscustomer" aria-describedby="emailHelp" placeholder="Enter Alamat Customer">
                    </div>
                    <div class="form-group col-md-7">
                        <label for="exampleInputEmail1">No Telepon</label>
                        <input type="text" class="form-control" name="telpcustomer" id="telpcustomer" aria-describedby="emailHelp" placeholder="Enter No Customer">
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-secondary" data-dismiss="modal" id="btn_close">Close</button>
                    <div id="divsave"><button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button></div>
                    <div id="divupdate"></div>

                    <!--Perhatikan divsave dan divupdate diatas
                      tujuannya agar ketika akan menggunakan form input button simpan dinamakan Save sedangkan untuk edit menjadi
                      button update
                      implementasi ada di java script di klik edit , btn_update dan btn_close-->
                </div>
            </div>
        </div>
    </div>
</form>
<!--END MODAL ADD-->

<!--MODAL DELETE ini untuk konfirmasi , agar ketika klik delete tidak langsung terhapus-->
<form>
    <div class="modal fade" id="Modal_Delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Customer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <strong>Are you sure to delete this record?</strong>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="idcustomer_delete" id="idcustomer_delete" class="form-control">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                    <button type="button" type="submit" id="btn_delete" class="btn btn-primary">Yes</button>
                </div>
            </div>
        </div>
    </div>
</form>
<!--END MODAL DELETE-->

<script type="text/javascript">
    $(document).ready(function() {

        show_customer(); //memanggil function yang ada di bawah
        //
        //
        //artinya yang ada pada bagian ini untuk mengeksekusi fuction apapun
        //
        //
        function show_customer() { //untuk menampilkan data product
            $.ajax({
                type: 'GET',
                url: '<?php echo site_url('Customers/getCustomer') ?>', //Memanggil Controller/Function
                async: false,
                dataType: 'json',
                success: function(data) {
                    var html = '';
                    var i;
                    var no;
                    for (i = 0; i < data.length; i++) { //looping atau pengulangan
                        no = i + 1;
                        html += '<tr>' +
                            '<td>' + no + '</td>' +
                            '<td>' + data[i].name_costumer + '</td>' +
                            '<td>' + data[i].address_costumer + '</td>' +
                            '<td>' + data[i].telp_costumer + '</td>' +
                            '<td style="text-align:center;">' +
                            '<a href="javascript:void(0);" class="btn btn-info btn-sm item_edit" data-idcustomer="' + data[i].id_costumer + '"><i class="fas fa-pencil-alt"></i></a>' + ' ' +
                            '<a href="javascript:void(0);" class="btn btn-danger btn-sm item_delete" data-idcustomer="' + data[i].id_costumer + '"><i class="fas fa-trash"></i></a>' +
                            '</td>' +
                            '</tr>';
                    } // akhir dari looping

                    $('#tblcustomer').html(html); // mengirim data
                }
            });
        }

        //Save product
        $('#btn_save').on('click', function() {
            var namacustomer = $('#namacustomer').val(); //deklarasi variabel $('#id yang digunakan pada textbox')
            var addresscustomer = $('#addresscustomer').val();
            var telpcustomer = $('#telpcustomer').val();

            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Customers/save') ?>", //Memanggil Controller/Function
                dataType: "JSON",
                data: {
                    namacustomer: namacustomer,
                    addresscustomer: addresscustomer,
                    telpcustomer: telpcustomer

                }, // menampung seluruh variable menjadi array
                success: function(data) { // setelah di simpan sudah seharusnya textbox yang diisi menjadi kosong
                    $('[name="namacustomer"]').val(""); // sehingga untuk mengosongkannya dengan cara berikut
                    $('[name="addresscustomer"]').val(""); //.val() untuk mengatur value yg ada di textbox
                    $('[name="telpcustomer"]').val("");
                    $('#FormModal').modal('hide');
                    show_customer(); // setelah disimpan tentunya harus di refresh di tampilkan kembali data terbaru 
                    // maka function ini kembali di panggil
                }
            });
            return false;
        });

        //Edit Data
        $('#tblcustomer').on('click', '.item_edit', function() {
            var idcustomer = $(this).data('idcustomer'); // variabel ini diambil dari data yg ada pada tabel 
            // silahkan perhartikan pada attribut  data-idproduct="'+dataXXXXX data-idproduct harus sama dengan .data('idproduct')
            // data-idproduct sebagai pengirim dan  $(this).data('idproduct');  sebagai penerima
            var btnupdate = '<button type="button" type="submit" id="btn_update" class="btn btn-primary">Update</button>';
            // deklarasi variable untuk menampilkan button Update
            $('#FormModal').modal('show'); //menampilkan formModal
            $('#divsave').html(""); // menyembunyikan button save
            $('#divupdate').html(btnupdate); // mengirim ke divupdate untuk di tampilkan
            $.ajax({
                type: 'POST',
                url: '<?php echo site_url('Customers/editCustomer') ?>', //Memanggil Controller/Function
                async: false,
                dataType: 'json',
                data: {
                    idcustomer: idcustomer
                },
                success: function(data) { //maka akan didapatkan data dari hasil pemanggilan controller di parsing menjadi JSON
                    $('[name="idcustomer"]').val(data[0].id_costumer);
                    $('[name="namacustomer"]').val(data[0].name_costumer);
                    $('[name="addresscustomer"]').val(data[0].address_costumer);
                    $('[name="telpcustomer"]').val(data[0].telp_costumer);
                }
            });
        });

        $('#divupdate').on('click', function() {
            var idcustomer = $('#idcustomer').val(); //mendeklarasikan data seperti pada button save
            var namacustomer = $('#namacustomer').val();
            var addresscustomer = $('#addresscustomer').val();
            var telpcustomer = $('#telpcustomer').val();
            $('#divsave').html('<button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button>');
            //setelah button update digunakan maka button update akan hilang dan diganti dengan button save
            $('#divupdate').html("");
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Customers/updateCustomer') ?>", // mengirim data yang di update
                dataType: "JSON",
                data: {
                    idcustomer: idcustomer,
                    namacustomer: namacustomer,
                    addresscustomer: addresscustomer,
                    telpcustomer: telpcustomer
                }, // data2 yang akan diupdate
                success: function(data) {
                    $('[name="idcustomer"]').val("");
                    $('[name="namacustomer"]').val(""); // sehingga untuk mengosongkannya dengan cara berikut
                    $('[name="addresscustomer"]').val(""); //.val() untuk mengatur value yg ada di textbox
                    $('[name="telpcustomer"]').val("");
                    $('#FormModal').modal('hide');
                    show_customer(); // ditampilkan kembali data dengan memanggi functionnya
                }
            });
            return false;
        });


        $('#btn_close').on('click', function() { //sudah di jelaskan sebelumnya diatas , maka pada form modal jika tidak mengisi form alias close maka tentu data semua harus kosong baik input ataupun update
            $('[name="idcustomer"]').val("");
            $('[name="namacustomer"]').val("");
            $('[name="addresscustomer"]').val("");
            $('[name="telpcustomer"]').val("");
            $('#FormModal').modal('hide');
            $('#divsave').html('<button type="button" type="submit" id="btn_save" class="btn btn-primary">Save</button>');
            $('#divupdate').html("");
        });

        $('#tblcustomer').on('click', '.item_delete', function() {
            var idcustomer = $(this).data('idcustomer'); // sama seperti edit hanya silahkan cek ke atas

            $('#Modal_Delete').modal('show'); //menampilkan modal delete atau pop up delete
            $('[name="idcustomer_delete"]').val(idcustomer);
        });

        //delete record to database
        $('#btn_delete').on('click', function() {
            var idcustomer = $('#idcustomer_delete').val(); //deklarasi
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Customers/delete') ?>", //memanggil contrroller/function
                dataType: "JSON",
                data: {
                    idcustomer: idcustomer
                }, //data yang dikirim untuk menghapus
                success: function(data) {
                    $('[name="idcustomer"]').val("");
                    $('#Modal_Delete').modal('hide');
                    show_customer(); // setelah di hapus pastinya ditampilkan kembali data yang terbaru
                }
            });
            return false;
        });

    });
</script>